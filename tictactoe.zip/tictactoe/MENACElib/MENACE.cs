namespace MENACElib;
[Serializable]
class MENACE
{
    public List<MatchBox>[] MatchBoxOfTurn { get; private set; }
    public MENACE()
    {
        MatchBoxOfTurn = new List<MatchBox>[9];
        for (int i = 0; i < 9; i++)
        {
            MatchBoxOfTurn[i] = new();
        }
    }
    private bool Add(MatchBox matchBox)
    {
        var temp = MatchBoxOfTurn[matchBox.State.GetTurnPassed()];
        if (temp.Contains(matchBox)) return false;
        temp.Add(matchBox);
        return true;
    }
    public byte nextMove(State state)
    {
        Add(new MatchBox(state));
        return MatchBoxOfTurn[state.GetTurnPassed()].Find(x => x.State.Equals(state)).MakeChoose();
    }
    public void Learn(List<byte> moves, bool isOWin)
    {
        for (int i = 0; i < moves.Count; i++)
        {
            var state = new State(moves.GetRange(0, i));
            Add(new MatchBox(state));
            MatchBoxOfTurn[i].Find(x => x.State.Equals(state)).Learn(moves[i], i % 2 == 0 ? isOWin : !isOWin);
        }
    }
    public void Train(string path)
    {
        using (StreamReader sr = new StreamReader(path))
        {
            while (!sr.EndOfStream)
            {
                string a = sr.ReadLine();
                System.Console.WriteLine(a);
                Learn((new List<char>(a)).ConvertAll(x => (byte)(x - '0')).GetRange(0, a.Length - 1), a.Last() == 'O');
            }
        }
    }
    public void Upload() 
    {
        Serializer s = new();
        s.MENACESerializer(this, @"D:\VTC\8.Project 1\tictactoe\Model.save");
    }
    public void Download()
    {
        Serializer s = new();
        MENACE temp = s.BinaryDeserializer(@"D:\VTC\8.Project 1\tictactoe\Model.save");
        this.MatchBoxOfTurn = temp.MatchBoxOfTurn;
    }
}