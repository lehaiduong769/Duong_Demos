﻿//using aTicTacToe;

//MENACE trainer = new();
//trainer.Train(@"D:\VTC\8.Project 1\tictactoe\TextFile1.txt");
//trainer.Upload();